<?php
require_once 'includes/header.php';
checkRole(['admin','manager']);
$branchId = $user['branch_id'];

if($_SERVER['REQUEST_METHOD']!=='POST'){ header('Location: cargo_service.php'); exit; }

$supplier_id = (int)($_POST['supplier_id'] ?? 0);
$provider_id = (int)($_POST['provider_id'] ?? 0);
$reference_no = trim($_POST['reference_no'] ?? '');
$description = trim($_POST['description'] ?? '');
$amount = (float)($_POST['amount'] ?? 0);

if($supplier_id<=0 || $provider_id<=0 || $amount<=0){
  $_SESSION['flash'] = ['type'=>'danger','msg'=>'Invalid input'];
  header('Location: cargo_service.php'); exit;
}

$pdo->beginTransaction();
try{
  // insert transfer
  $stmt = $pdo->prepare("INSERT INTO cargo_services (branch_id, supplier_id, cargo_provider_id, reference_no, description, amount, created_by) 
                         VALUES (?,?,?,?,?,?,?)");
  $stmt->execute([$branchId, $supplier_id, $provider_id, $reference_no, $description, $amount, $user['id']]);

  // journal entries (supplier -amount ; cargo +amount)
  $j = $pdo->prepare("INSERT INTO journal_entries (branch_id, entry_date, account_type, amount, description, created_by)
                      VALUES (?, CURRENT_DATE(), ?, ?, ?, ?)");

  $j->execute([$branchId, 'supplier', -$amount, "Cargo transfer ref {$reference_no}", $user['id']]);
  $j->execute([$branchId, 'cargo',     $amount, "Cargo transfer ref {$reference_no}", $user['id']]);

  $pdo->commit();
  $_SESSION['flash'] = ['type'=>'success','msg'=>'Cargo transfer created'];
}catch(Exception $e){
  $pdo->rollBack();
  error_log($e->getMessage());
  $_SESSION['flash'] = ['type'=>'danger','msg'=>'Failed to create cargo transfer'];
}
header('Location: cargo_service.php');
