<?php
require_once 'includes/header.php';
checkRole(['admin','manager']);
$branchId = $user['branch_id'];
?>

<?php
// Fetch dropdowns
$providers = $pdo->query("SELECT id, name FROM cargo_providers WHERE is_active=1 ORDER BY name")->fetchAll();
$suppliers = $pdo->query("SELECT id, name FROM suppliers ORDER BY name")->fetchAll();
?>
<div class="container-fluid">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h3 class="mb-0">Cargo Services</h3>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTransfer">New Transfer</button>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <form class="row g-2" method="get">
        <div class="col-md-3">
          <label class="form-label">Provider</label>
          <select name="provider_id" class="form-select">
            <option value="">All</option>
            <?php foreach($providers as $p): ?>
              <option value="<?= $p['id'] ?>" <?= (($_GET['provider_id'] ?? '')==$p['id']?'selected':'') ?>><?= htmlspecialchars($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">From</label>
          <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($_GET['from'] ?? '') ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">To</label>
          <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($_GET['to'] ?? '') ?>">
        </div>
        <div class="col-md-3 d-flex align-items-end">
          <button class="btn btn-secondary me-2">Filter</button>
          <a href="cargo_service.php" class="btn btn-outline-secondary">Reset</a>
        </div>
      </form>
    </div>
  </div>

  <?php
    // build filter
    $where = ["cs.branch_id = :bid"];
    $params = [":bid"=>$branchId];
    if (!empty($_GET['provider_id'])) { $where[] = "cs.cargo_provider_id = :pid"; $params[':pid'] = (int)$_GET['provider_id']; }
    if (!empty($_GET['from'])) { $where[] = "date(cs.transfer_date) >= :from"; $params[':from'] = $_GET['from']; }
    if (!empty($_GET['to'])) { $where[] = "date(cs.transfer_date) <= :to"; $params[':to'] = $_GET['to']; }
    $sql = "SELECT cs.*, s.name AS supplier_name, p.name AS provider_name
            FROM cargo_services cs
            JOIN suppliers s ON s.id = cs.supplier_id
            JOIN cargo_providers p ON p.id = cs.cargo_provider_id
            WHERE ".implode(" AND ", $where)." ORDER BY cs.transfer_date DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    // balances per provider (branch scoped)
    $bal = $pdo->prepare("SELECT * FROM v_cargo_provider_balance WHERE branch_id=:bid");
    $bal->execute([":bid"=>$branchId]);
    $balances = [];
    foreach($bal->fetchAll() as $b){ $balances[$b['cargo_provider_id']] = $b; }
  ?>

  <div class="card">
    <div class="card-body table-responsive">
      <table class="table table-sm table-striped align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>Date</th>
            <th>Supplier</th>
            <th>Provider</th>
            <th>Reference</th>
            <th class="text-end">Amount</th>
            <th class="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($rows as $r): ?>
            <tr>
              <td><?= (int)$r['id'] ?></td>
              <td><?= htmlspecialchars($r['transfer_date']) ?></td>
              <td><?= htmlspecialchars($r['supplier_name']) ?></td>
              <td>
                <?= htmlspecialchars($r['provider_name']) ?>
                <?php if(isset($balances[$r['cargo_provider_id']])): 
                        $b=$balances[$r['cargo_provider_id']]; ?>
                  <div class="small text-muted">Provider Balance: Rs. <?= number_format($b['balance'],2) ?></div>
                <?php endif; ?>
              </td>
              <td><?= htmlspecialchars($r['reference_no']) ?></td>
              <td class="text-end"><?= number_format($r['amount'],2) ?></td>
              <td class="text-center">
                <button class="btn btn-sm btn-success" 
                        onclick="openPayModal(<?= (int)$r['cargo_provider_id'] ?>, '<?= htmlspecialchars($r['provider_name'], ENT_QUOTES) ?>')">
                  Pay
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- New Transfer Modal -->
<div class="modal fade" id="modalTransfer" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post" action="cargo_service_add.php">
      <div class="modal-header"><h5 class="modal-title">New Cargo Transfer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2">
          <label class="form-label">Supplier</label>
          <select name="supplier_id" class="form-select" required>
            <?php foreach($suppliers as $s): ?>
              <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2">
          <label class="form-label">Provider</label>
          <select name="provider_id" class="form-select" required>
            <?php foreach($providers as $p): ?>
              <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="row">
          <div class="col-md-6 mb-2">
            <label class="form-label">Reference</label>
            <input type="text" name="reference_no" class="form-control">
          </div>
          <div class="col-md-6 mb-2">
            <label class="form-label">Amount (Rs.)</label>
            <input type="number" step="0.01" min="0.01" name="amount" class="form-control" required>
          </div>
        </div>
        <div class="mb-2">
          <label class="form-label">Remarks</label>
          <input type="text" name="description" class="form-control">
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Save Transfer</button>
      </div>
    </form>
  </div>
</div>

<!-- Pay Modal -->
<div class="modal fade" id="modalPay" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post" action="cargo_service_pay.php">
      <div class="modal-header"><h5 class="modal-title">Pay Cargo Provider</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="provider_id" id="pay_provider_id">
        <div class="mb-2">
          <label class="form-label">Provider</label>
          <input type="text" class="form-control" id="pay_provider_name" disabled>
        </div>
        <div class="row">
          <div class="col-md-6 mb-2">
            <label class="form-label">Amount (Rs.)</label>
            <input type="number" step="0.01" min="0.01" name="amount" class="form-control" required>
          </div>
          <div class="col-md-6 mb-2">
            <label class="form-label">Method</label>
            <select name="method" class="form-select" required>
              <option value="cash">Cash</option>
              <option value="bank">Bank</option>
              <option value="card">Card</option>
              <option value="cheque">Cheque</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 mb-2">
            <label class="form-label">Bank Account (if bank/card)</label>
            <select name="bank_account_id" class="form-select">
              <option value="">-- Select --</option>
              <?php
                $banks = $pdo->prepare("SELECT id, name, account_no FROM bank_accounts WHERE branch_id=:b OR branch_id IS NULL");
                $banks->execute([":b"=>$branchId]);
                foreach($banks->fetchAll() as $bk){
                  echo '<option value="'.$bk['id'].'">'.htmlspecialchars($bk['name'].' ('.$bk['account_no'].')').'</option>';
                }
              ?>
            </select>
          </div>
          <div class="col-md-6 mb-2">
            <label class="form-label">Cheque No (if cheque)</label>
            <input type="text" name="cheque_no" class="form-control">
          </div>
        </div>
        <div class="mb-2">
          <label class="form-label">Notes</label>
          <input type="text" name="notes" class="form-control">
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Pay</button>
      </div>
    </form>
  </div>
</div>

<script>
function openPayModal(pid, pname){
  document.getElementById('pay_provider_id').value = pid;
  document.getElementById('pay_provider_name').value = pname;
  var m = new bootstrap.Modal(document.getElementById('modalPay'));
  m.show();
}
</script>
<?php require_once 'includes/footer.php'; ?>
