<?php
require_once 'includes/header.php';
checkRole(['admin','manager']);
$branchId = $user['branch_id'];

if($_SERVER['REQUEST_METHOD']!=='POST'){ header('Location: cargo_service.php'); exit; }

$provider_id = (int)($_POST['provider_id'] ?? 0);
$amount = (float)($_POST['amount'] ?? 0);
$method = $_POST['method'] ?? 'cash';
$bank_account_id = !empty($_POST['bank_account_id']) ? (int)$_POST['bank_account_id'] : NULL;
$cheque_no = trim($_POST['cheque_no'] ?? '');
$notes = trim($_POST['notes'] ?? '');

if($provider_id<=0 || $amount<=0){
  $_SESSION['flash'] = ['type'=>'danger','msg'=>'Invalid input'];
  header('Location: cargo_service.php'); exit;
}

$pdo->beginTransaction();
try{
  // record payment
  $stmt = $pdo->prepare("INSERT INTO cargo_payments (cargo_provider_id, branch_id, method, bank_account_id, cheque_no, amount, paid_by, notes)
                         VALUES (?,?,?,?,?,?,?,?)");
  $stmt->execute([$provider_id, $branchId, $method, $bank_account_id, $cheque_no, $amount, $user['id'], $notes]);

  // journal entries (reduce asset + reduce liability)
  $j = $pdo->prepare("INSERT INTO journal_entries (branch_id, entry_date, account_type, amount, description, created_by)
                      VALUES (?, CURRENT_DATE(), ?, ?, ?, ?)");

  if($method==='cash'){
    $j->execute([$branchId, 'cash', -$amount, 'Cargo provider payment (cash)', $user['id']]);
  }else{
    $j->execute([$branchId, 'bank', -$amount, 'Cargo provider payment (' . $method . ')', $user['id']]);
  }
  $j->execute([$branchId, 'cargo', -$amount, 'Cargo provider payment', $user['id']]);

  $pdo->commit();
  $_SESSION['flash'] = ['type'=>'success','msg'=>'Payment recorded'];
}catch(Exception $e){
  $pdo->rollBack();
  error_log($e->getMessage());
  $_SESSION['flash'] = ['type'=>'danger','msg'=>'Failed to record payment'];
}
header('Location: cargo_service.php');
