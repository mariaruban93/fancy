
-- =============================================
-- Cargo Service Feature - DB Changes & Views
-- Compatible with multi_branch_pos_31 schema
-- Generated: 2025-09-21T18:24:22
-- =============================================

START TRANSACTION;

-- 1) Extend journal_entries to include 'cargo' account type (idempotent pattern)
ALTER TABLE journal_entries
  MODIFY account_type ENUM('stock','cash','supplier','customer','other','bank','wallet','cargo') NOT NULL;

-- 2) Cargo Providers master (who we owe for cargo services)
CREATE TABLE IF NOT EXISTS cargo_providers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(50) DEFAULT NULL,
  address VARCHAR(255) DEFAULT NULL,
  is_active TINYINT(1) DEFAULT 1,
  created_by INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 3) Cargo Service transfers (from supplier payable to cargo payable)
CREATE TABLE IF NOT EXISTS cargo_services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  branch_id INT NOT NULL,
  supplier_id INT NOT NULL,
  cargo_provider_id INT NOT NULL,
  transfer_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reference_no VARCHAR(50) DEFAULT NULL,
  description VARCHAR(255) DEFAULT NULL,
  amount DECIMAL(12,2) NOT NULL,
  created_by INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_branch (branch_id),
  INDEX idx_supplier (supplier_id),
  INDEX idx_provider (cargo_provider_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 4) Payments made to cargo providers
CREATE TABLE IF NOT EXISTS cargo_payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cargo_provider_id INT NOT NULL,
  branch_id INT NOT NULL,
  method ENUM('cash','bank','card','cheque') NOT NULL,
  bank_account_id INT DEFAULT NULL,
  cheque_no VARCHAR(100) DEFAULT NULL,
  amount DECIMAL(12,2) NOT NULL,
  paid_by INT NOT NULL,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  notes VARCHAR(255) DEFAULT NULL,
  INDEX idx_provider (cargo_provider_id),
  INDEX idx_branch (branch_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 5) Seed one provider if empty
INSERT INTO cargo_providers (name, created_by)
SELECT * FROM (SELECT 'Default Cargo', 1) AS t
WHERE NOT EXISTS (SELECT 1 FROM cargo_providers);

-- 6) Views to compute cargo payable (per provider & per branch)
DROP VIEW IF EXISTS v_cargo_provider_balance;
CREATE VIEW v_cargo_provider_balance AS
SELECT
  p.id AS cargo_provider_id,
  p.name AS cargo_provider_name,
  cs.branch_id,
  COALESCE(SUM(cs.amount),0) AS total_transferred,
  COALESCE((SELECT SUM(cp.amount) FROM cargo_payments cp 
            WHERE cp.cargo_provider_id = p.id AND cp.branch_id = cs.branch_id),0) AS total_paid,
  COALESCE(SUM(cs.amount),0) - 
  COALESCE((SELECT SUM(cp.amount) FROM cargo_payments cp 
            WHERE cp.cargo_provider_id = p.id AND cp.branch_id = cs.branch_id),0) AS balance
FROM cargo_providers p
LEFT JOIN cargo_services cs ON cs.cargo_provider_id = p.id
GROUP BY p.id, cs.branch_id;

DROP VIEW IF EXISTS v_branch_cargo_payable;
CREATE VIEW v_branch_cargo_payable AS
SELECT branch_id, COALESCE(SUM(balance),0) AS cargo_payable
FROM v_cargo_provider_balance
GROUP BY branch_id;

COMMIT;

-- ========= Journal Entry Guidance (implemented in PHP):
-- On transfer (supplier -> cargo):
--   journal_entries: supplier  amount = -{A}  (reduces supplier payable)
--   journal_entries: cargo     amount =  {A}  (increases cargo payable)
-- On pay cargo by cash:
--   journal_entries: cash      amount = -{A}  (reduces cash asset)
--   journal_entries: cargo     amount = -{A}  (reduces cargo payable)
-- On pay cargo by bank/card/cheque: same but use 'bank' and set bank_account_id in cargo_payments
-- =============================================
