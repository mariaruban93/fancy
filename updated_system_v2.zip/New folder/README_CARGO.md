# Cargo Service Add-on (POS v31)

This package adds a **Cargo Service** workflow:
- Transfer expense from a **Supplier payable** to a **Cargo Provider payable**
- Record payments to cargo provider via **Cash / Bank / Card / Cheque**
- Liabilities and cash/bank balances update via `journal_entries`
- New views: `v_cargo_provider_balance`, `v_branch_cargo_payable`

## Install

1) **DB**: run SQL

```bash
mysql -u root -p multi_branch_pos_31 < multi_branch_pos_31_cargo.sql
```

2) **Code**: copy these files to your project root (where `includes/` exists):
- `cargo_service.php`
- `cargo_service_add.php`
- `cargo_service_pay.php`

3) **Menu**: add this snippet to your sidebar (e.g., `includes/sidebar.php`):

```html

<li class="<?= ($page??'')==='cargo' ? 'active' : '' ?>">
  <a href="cargo_service.php"><i class="fa fa-truck"></i> <span>Cargo Services</span></a>
</li>

```

4) **Permissions**: both Admin & Manager can access by default (edit `checkRole` if needed).

## Accounting Flow

**Transfer** (Supplier -> Cargo):
- `journal_entries`: `supplier` **-amount** (reduces supplier payable)
- `journal_entries`: `cargo` **+amount** (increases cargo payable)

**Pay Cargo** (Cash/Bank/Card/Cheque):
- `journal_entries`: `cash` or `bank` **-amount** (reduces asset)
- `journal_entries`: `cargo` **-amount** (reduces cargo payable)

Use `v_cargo_provider_balance` for provider-wise balances and `v_branch_cargo_payable` to plug into your balance sheet (liabilities).
