<?php
/**
 * cheques_in_hand.php
 *
 * Lists all undeposited cheque payments from customers.  Admins may filter by
 * branch, while managers are limited to their own branch.  Each row shows
 * the payment details along with the date the payment was recorded.  Users
 * can mark a cheque as deposited by selecting a deposit date; the deposit
 * status is then updated via an AJAX call to ajax_deposit_cheque.php.
 */

require_once 'includes/header.php';
// Only admin and manager roles may view and deposit cheques
checkRole(['admin','manager']);

// Determine branch filter: managers are locked to their branch; admin can choose
$is_admin = ($user['role_name'] === 'admin');
$filter_branch_id = 0;
if ($is_admin) {
    if (isset($_GET['branch_id']) && ctype_digit($_GET['branch_id'])) {
        $filter_branch_id = (int)$_GET['branch_id'];
    }
} else {
    $filter_branch_id = (int)($user['branch_id'] ?? 0);
}

// Fetch branches for filter dropdown (admin only)
$branches = [];
if ($is_admin) {
    $branches = $pdo->query("SELECT id, name FROM branches ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch undeposited cheques.  Some older databases may not have a created_at
// column on sale_payments.  To remain backward compatible we detect its
// presence and adjust the SELECT and ORDER BY clauses accordingly.  If
// created_at is absent we fall back to using the sale_date as the
// timestamp for ordering.
$hasCreatedAt = false;
try {
    $checkCol = $pdo->query("SHOW COLUMNS FROM sale_payments LIKE 'created_at'")->fetch();
    if ($checkCol) {
        $hasCreatedAt = true;
    }
} catch (Throwable $ignored) {
    $hasCreatedAt = false;
}
if ($hasCreatedAt) {
    $selectCreated = "sp.created_at";
    $orderBy = "ORDER BY sp.created_at DESC";
} else {
    // Use the sale date as a proxy for when the payment was recorded
    $selectCreated = "s.sale_date";
    $orderBy = "ORDER BY s.sale_date DESC";
}
$sql = "SELECT sp.id AS payment_id, sp.sale_id, sp.amount, sp.cheque_number, sp.bank_name, sp.bank_branch, sp.deposit_date, " . $selectCreated . " AS created_at,
               IFNULL(c.name, 'Walk-in') AS customer_name, s.sale_date, s.branch_id, b.name AS branch_name
        FROM sale_payments sp
        JOIN sales s ON sp.sale_id = s.id
        JOIN branches b ON s.branch_id = b.id
        LEFT JOIN customers c ON s.customer_id = c.id
        WHERE sp.method = 'cheque' AND sp.deposit_date IS NULL";
$params = [];
if ($filter_branch_id) {
    $sql .= " AND s.branch_id = ?";
    $params[] = $filter_branch_id;
}
$sql .= ' ' . $orderBy;
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$cheques = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch bank accounts once and group by branch for quick lookup.  We include
// accounts where branch_id is NULL (global) under key 0.
$banksByBranch = [];
$rows = $pdo->query("SELECT id, name, branch_id FROM bank_accounts ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $bk) {
    $bid = $bk['branch_id'] === null ? 0 : (int)$bk['branch_id'];
    if (!isset($banksByBranch[$bid])) $banksByBranch[$bid] = [];
    $banksByBranch[$bid][] = $bk;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cheques In Hand - POS System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>
<div class="container">
    <h1 class="mb-4">Cheques In Hand</h1>
    <!-- Branch filter for admin -->
    <?php if ($is_admin): ?>
    <form method="get" class="row g-3 mb-3">
        <div class="col-md-4">
            <label class="form-label">Branch</label>
            <select name="branch_id" class="form-select" onchange="this.form.submit()">
                <option value="">All Branches</option>
                <?php foreach ($branches as $br): ?>
                    <option value="<?php echo (int)$br['id']; ?>" <?php echo ($filter_branch_id == $br['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($br['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>
    <?php endif; ?>
    <div class="table-responsive">
        <table id="chequeTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Sale ID</th>
                    <?php if ($is_admin): ?><th>Branch</th><?php endif; ?>
                    <th>Customer</th>
                    <th>Amount (Rs.)</th>
                    <th>Cheque #</th>
                    <th>Bank</th>
                    <th>Branch</th>
                    <th>Created At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cheques as $chk): ?>
                <tr>
                    <td><?php echo (int)$chk['payment_id']; ?></td>
                    <td><?php echo (int)$chk['sale_id']; ?></td>
                    <?php if ($is_admin): ?><td><?php echo htmlspecialchars($chk['branch_name']); ?></td><?php endif; ?>
                    <td><?php echo htmlspecialchars($chk['customer_name']); ?></td>
                    <td class="text-end"><?php echo number_format((float)$chk['amount'], 2); ?></td>
                    <td><?php echo htmlspecialchars($chk['cheque_number']); ?></td>
                    <td><?php echo htmlspecialchars($chk['bank_name']); ?></td>
                    <td><?php echo htmlspecialchars($chk['bank_branch']); ?></td>
                    <td><?php echo htmlspecialchars(date('d-M-Y', strtotime($chk['created_at']))); ?></td>
                    <td>
                        <!-- Deposit button triggers modal -->
                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#depositModal<?php echo (int)$chk['payment_id']; ?>">Deposit</button>
                    </td>
                </tr>
                <!-- Deposit modal for this cheque -->
                <div class="modal fade" id="depositModal<?php echo (int)$chk['payment_id']; ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Deposit Cheque #<?php echo htmlspecialchars($chk['cheque_number']); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p><strong>Customer:</strong> <?php echo htmlspecialchars($chk['customer_name']); ?><br>
                                   <strong>Amount:</strong> Rs. <?php echo number_format((float)$chk['amount'], 2); ?><br>
                                   <strong>Bank:</strong> <?php echo htmlspecialchars($chk['bank_name']); ?>, <?php echo htmlspecialchars($chk['bank_branch']); ?></p>
                                <div class="mb-3">
                                    <label class="form-label">Deposit Date</label>
                                    <input type="date" class="form-control deposit-date-input" id="depositDate<?php echo (int)$chk['payment_id']; ?>" value="<?php echo date('Y-m-d'); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Deposit To Bank</label>
                                    <select class="form-select" id="bankId<?php echo (int)$chk['payment_id']; ?>">
                                        <?php
                                        // Build bank options for this sale's branch.  Include banks belonging to
                                        // the same branch as the sale and global accounts (branch_id NULL).  If
                                        // none are available, leave the select empty.
                                        $bId = (int)$chk['branch_id'];
                                        $options = [];
                                        if (isset($banksByBranch[$bId])) {
                                            $options = array_merge($options, $banksByBranch[$bId]);
                                        }
                                        if (isset($banksByBranch[0])) {
                                            $options = array_merge($options, $banksByBranch[0]);
                                        }
                                        foreach ($options as $bank): ?>
                                            <option value="<?php echo (int)$bank['id']; ?>"><?php echo htmlspecialchars($bank['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-primary deposit-btn" data-id="<?php echo (int)$chk['payment_id']; ?>">Confirm Deposit</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    $('#chequeTable').DataTable();
    // Handle deposit button click
    $(document).on('click', '.deposit-btn', function() {
        const paymentId = $(this).data('id');
        const dateInput  = $('#depositDate' + paymentId);
        const bankSelect = $('#bankId' + paymentId);
        const depositDate = dateInput.val();
        const bankId      = bankSelect.val();
        if (!depositDate) {
            alert('Please select a deposit date.');
            return;
        }
        if (!bankId) {
            alert('Please select a bank to deposit into.');
            return;
        }
        // Confirmation
        if (!confirm('Are you sure you want to mark this cheque as deposited on ' + depositDate + '?')) {
            return;
        }
        // Send AJAX request
        $.post('ajax_deposit_cheque.php', {payment_id: paymentId, deposit_date: depositDate, bank_id: bankId}, function(resp) {
            if (resp.status === 'success') {
                // Reload page to reflect changes
                location.reload();
            } else {
                alert(resp.message || 'Failed to deposit cheque');
            }
        }, 'json').fail(function() {
            alert('Error communicating with server');
        });
    });
});
</script>
</body>
</html>