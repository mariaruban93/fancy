<?php
require_once 'includes/header.php';
// Only admin can delete suppliers
checkRole(['admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}
csrf_check();

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    exit('Invalid supplier ID');
}

$pdo->beginTransaction();
try {
    // Check if supplier has purchases; prevent deletion if purchases exist
    $check = $pdo->prepare('SELECT COUNT(*) FROM purchases WHERE supplier_id = ?');
    $check->execute([$id]);
    if ((int)$check->fetchColumn() > 0) {
        throw new RuntimeException('Supplier has purchases. Remove or reassign them before deletion.');
    }
    $stmt = $pdo->prepare('DELETE FROM suppliers WHERE id = ?');
    $stmt->execute([$id]);
    $pdo->commit();
    header('Location: suppliers.php?msg=deleted');
    exit;
} catch (Throwable $e) {
    $pdo->rollBack();
    http_response_code(500);
    exit('Failed to delete supplier: ' . $e->getMessage());
}