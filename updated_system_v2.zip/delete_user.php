<?php
/**
 * delete_user.php
 *
 * Handles deletion of a user account. Only administrators may perform this action.
 * Implements safety checks to prevent an admin from deleting themselves or from
 * deleting the last remaining admin account, which would lock everyone out.
 */
require_once 'includes/header.php';

// Only administrators can delete users
checkRole(['admin']);

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}

// Validate CSRF token
csrf_check();

// Retrieve user ID to delete
$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    exit('Invalid user ID');
}

// Prevent deleting yourself
if ($id === (int)$user['id']) {
    http_response_code(400);
    exit('You cannot delete your own account.');
}

// Fetch the role name of the target user
$stmt = $pdo->prepare(
    'SELECT u.id, r.name AS role_name FROM users u ' .
    'JOIN roles r ON u.role_id = r.id WHERE u.id = ?'
);
$stmt->execute([$id]);
$target = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$target) {
    http_response_code(404);
    exit('User not found');
}

// Check if the target user is an admin
$isAdmin = ($target['role_name'] === 'admin');

// Count how many admin users exist
$stmtCount = $pdo->query(
    "SELECT COUNT(*) FROM users u JOIN roles r ON u.role_id = r.id WHERE r.name = 'admin'"
);
$adminCount = (int)$stmtCount->fetchColumn();

// Prevent deleting the last remaining admin
if ($isAdmin && $adminCount <= 1) {
    http_response_code(400);
    exit('Cannot delete the last admin account.');
}

// Perform deletion
try {
    $pdo->beginTransaction();
    $del = $pdo->prepare('DELETE FROM users WHERE id = ?');
    $del->execute([$id]);
    $pdo->commit();
    header('Location: users.php?msg=deleted');
    exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    exit('Delete failed: ' . $e->getMessage());
}