<?php
/**
 * Activity Log report page
 * Shows a list of logged user activities for admins and managers.  Admins can
 * filter by branch; managers automatically see only their branch activities.
 */
require_once 'includes/header.php';
// Restrict to admin or manager
checkRole(['admin','manager']);

// Default filters
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date   = isset($_GET['end_date']) ? $_GET['end_date'] : '';
$branch_filter = '';
if ($user['role_name'] === 'admin') {
    $branch_filter = isset($_GET['branch_id']) ? $_GET['branch_id'] : '';
    // Fetch branches for dropdown
    $branchOptions = $pdo->query("SELECT id, name FROM branches ORDER BY name")->fetchAll();
}

// Build query for logs
$query = "SELECT al.*, u.username AS user_name, b.name AS branch_name "
       . "FROM activity_logs al "
       . "JOIN users u ON al.user_id = u.id "
       . "LEFT JOIN branches b ON al.branch_id = b.id WHERE 1=1";
$params = [];
// Apply date filters if provided
if ($start_date) {
    $query .= " AND DATE(al.created_at) >= ?";
    $params[] = $start_date;
}
if ($end_date) {
    $query .= " AND DATE(al.created_at) <= ?";
    $params[] = $end_date;
}
// Restrict by role/branch
if ($user['role_name'] === 'manager') {
    $query .= " AND al.branch_id = ?";
    $params[] = $user['branch_id'];
} elseif ($branch_filter) {
    $query .= " AND al.branch_id = ?";
    $params[] = $branch_filter;
}
// Order by newest first
$query .= " ORDER BY al.created_at DESC";
// Execute query
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$logs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Logs - POS System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>
<div class="container">
    <h1 class="mb-4">Activity Logs</h1>
    <form method="get" class="row g-3 mb-4">
        <div class="col-md-3">
            <label class="form-label">Start Date</label>
            <input type="date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>">
        </div>
        <div class="col-md-3">
            <label class="form-label">End Date</label>
            <input type="date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>">
        </div>
        <?php if ($user['role_name'] === 'admin'): ?>
        <div class="col-md-3">
            <label class="form-label">Branch</label>
            <select name="branch_id" class="form-select">
                <option value="">All</option>
                <?php foreach ($branchOptions as $br): ?>
                    <option value="<?php echo $br['id']; ?>" <?php echo ($branch_filter == $br['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($br['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <div class="col-md-3 align-self-end">
            <button type="submit" class="btn btn-primary">Filter</button>
        </div>
    </form>
    <div class="table-responsive">
        <table id="activityTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date & Time</th>
                    <th>User</th>
                    <th>Branch</th>
                    <th>Action</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo (int)$log['id']; ?></td>
                        <td><?php echo htmlspecialchars($log['created_at']); ?></td>
                        <td><?php echo htmlspecialchars($log['user_name']); ?></td>
                        <td><?php echo htmlspecialchars($log['branch_name'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($log['action']); ?></td>
                        <td><?php echo htmlspecialchars($log['description']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- jQuery and DataTables JS -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    $('#activityTable').DataTable();
});
</script>
</body>
</html>