<?php
/**
 * Expenses management page.
 * Allows admins and managers to record and view branch expenses such as rent, utilities, etc.
 * Managers are restricted to their own branch, while admins can choose any branch.
 */
require_once 'includes/header.php';

// Only admin and manager roles can access
checkRole(['admin', 'manager']);

$message = '';

// Fetch active branches for admin branch selector
$branches = [];
try {
    $branches = $pdo->query("SELECT id, name FROM branches WHERE is_active = 1 ORDER BY name")->fetchAll();
} catch (Throwable $e) {
    $branches = [];
}

// Determine the branch context for listing expenses. Admin can filter by GET; manager uses own branch.
$list_branch_id = null;
if ($user['role_name'] === 'admin') {
    if (isset($_GET['branch_id']) && ctype_digit($_GET['branch_id'])) {
        $list_branch_id = (int)$_GET['branch_id'];
    }
} else {
    $list_branch_id = (int)($user['branch_id'] ?? 0);
}

// Handle new expense submission
if (isset($_POST['add_expense'])) {
    // Branch determination: admin chooses from form, manager uses own
    $branch_id = null;
    if ($user['role_name'] === 'admin') {
        $branch_id = isset($_POST['branch_id']) && $_POST['branch_id'] !== '' ? (int)$_POST['branch_id'] : null;
    } else {
        $branch_id = (int)$user['branch_id'];
    }
    $date = trim($_POST['expense_date'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $subcategory = trim($_POST['subcategory'] ?? '');
    $payment_method = trim($_POST['payment_method'] ?? '');
    $payee_name = trim($_POST['payee_name'] ?? '');
    $amount = trim($_POST['amount'] ?? '');

    // Validate inputs
    if ($branch_id && $date && $desc && is_numeric($amount)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO expenses (branch_id, expense_date, description, category, subcategory, payment_method, payee_name, amount, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$branch_id, $date, $desc, $category, $subcategory, $payment_method, $payee_name, (float)$amount, $user['id']]);
            $message = 'Expense added successfully!';
        } catch (Throwable $e) {
            $message = 'Error adding expense: ' . $e->getMessage();
        }
    } else {
        $message = 'All fields are required and amount must be numeric.';
    }
}

// Build query to fetch expenses
$expenses = [];
try {
    if ($user['role_name'] === 'admin') {
        // Admin can view all or filter by branch
        if ($list_branch_id) {
            $stmt = $pdo->prepare("SELECT e.*, b.name AS branch_name, u.username AS created_by_name FROM expenses e JOIN branches b ON e.branch_id = b.id JOIN users u ON e.created_by = u.id WHERE e.branch_id = ? ORDER BY e.expense_date DESC, e.id DESC");
            $stmt->execute([$list_branch_id]);
        } else {
            $stmt = $pdo->query("SELECT e.*, b.name AS branch_name, u.username AS created_by_name FROM expenses e JOIN branches b ON e.branch_id = b.id JOIN users u ON e.created_by = u.id ORDER BY e.expense_date DESC, e.id DESC");
        }
    } else {
        // Manager sees only own branch expenses
        $stmt = $pdo->prepare("SELECT e.*, b.name AS branch_name, u.username AS created_by_name FROM expenses e JOIN branches b ON e.branch_id = b.id JOIN users u ON e.created_by = u.id WHERE e.branch_id = ? ORDER BY e.expense_date DESC, e.id DESC");
        $stmt->execute([$user['branch_id']]);
    }
    $expenses = $stmt->fetchAll();
} catch (Throwable $e) {
    $expenses = [];
}

// Calculate total expenses for the current list
$total_expense = 0.0;
foreach ($expenses as $ex) {
    $total_expense += (float)$ex['amount'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expenses - POS System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>
<div class="container">
    <h1 class="mb-4">Expenses</h1>
    <?php if ($message): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <!-- Add expense form -->
    <div class="card mb-4">
        <div class="card-header">Add New Expense</div>
        <div class="card-body">
            <form method="post" class="row g-3 align-items-end">
                <?php if ($user['role_name'] === 'admin'): ?>
                    <div class="col-md-4">
                        <label class="form-label">Branch</label>
                        <select name="branch_id" class="form-select" required>
                            <option value="">Select Branch</option>
                            <?php foreach ($branches as $br): ?>
                                <option value="<?php echo (int)$br['id']; ?>" <?php echo ($list_branch_id && $list_branch_id == $br['id'] ? 'selected' : ''); ?>><?php echo htmlspecialchars($br['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="col-md-4">
                    <label class="form-label">Date</label>
                    <input type="date" name="expense_date" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Description</label>
                    <input type="text" name="description" class="form-control" placeholder="Expense description" required>
                </div>
                 <!-- Category Filter -->
                   <div class="col-md-4">
            <div class="filter-row d-flex align-items-center">
                <div class="filter-icon">
                    <i class="bi bi-tag"></i>
                </div>
                <div class="flex-grow-1">
                    <label class="form-label">Filter by Category</label>
                    <select name="category" class="form-select">
                        <option value="">All Categories</option>
                        <option value="salary">Salary</option>
                        <option value="entertainment">Entertainment</option>
                        <option value="office">Office</option>
                        <option value="personal">Personal</option>
                        <option value="utility">Utility</option>
                        <option value="grocery">Grocery</option>
                        <option value="food_city">Food City</option>
                        <option value="others">Others</option>
                    </select>
                </div>
            </div>
                            </div>
            
            <!-- Subcategory Filter -->
              <div class="col-md-4">
            <div class="filter-row d-flex align-items-center">
                <div class="filter-icon">
                    <i class="bi bi-tags"></i>
                </div>
                <div class="flex-grow-1">
                    <label class="form-label">Filter by Subcategory</label>
                    <select name="subcategory" class="form-select">
                        <option value="">All Subcategories</option>
                        <option value="office">Office</option>
                        <option value="restaurants">Restaurants</option>
                        <option value="postage">Postage</option>
                        <option value="printing">Printing</option>
                        <option value="stationery">Stationery</option>
                        <option value="vehicle_rent">Vehicle Rent</option>
                        <option value="phone_fees">Phone Fees</option>
                        <option value="other">Other</option>
                    </select>
                </div>
            </div>
                            </div>
            <!-- Payment Method Filter -->
              <div class="col-md-4">
            <div class="filter-row d-flex align-items-center">
                <div class="filter-icon">
                    <i class="bi bi-credit-card"></i>
                </div>
                <div class="flex-grow-1">
                    <label class="form-label">Filter by Payment Method</label>
                    <select name="payment_method" class="form-select">
                        <option value="">All Payment Methods</option>
                        <option value="cash">Cash</option>
                        <option value="cheque">Cheque</option>
                        <option value="card">Card</option>
                        <option value="credit">Credit</option>
                        <option value="online">Online Transaction</option>
                    </select>
                </div>
            </div>
                            </div>
                            <div class="col-md-4">
                    <label class="form-label">Payee Name</label>
                    <input type="text" name="payee_name" class="form-control" step="0.01" min="0" placeholder="0.00" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Amount</label>
                    <input type="number" name="amount" class="form-control" step="0.01" min="0" placeholder="0.00" required>
                </div>
                <div class="col-md-4">
                    <button type="submit" name="add_expense" class="btn btn-primary w-100">Add</button>
                </div>
            </form>
        </div>
    </div>
    <!-- Total expense summary -->
    <div class="alert alert-secondary"><strong>Total Expense:</strong> Rs. <?php echo number_format($total_expense, 2); ?></div>
    <!-- Expenses table -->
    <div class="table-responsive">
        <table id="expensesTable" class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>ID</th>
                <?php if ($user['role_name'] === 'admin'): ?><th>Branch</th><?php endif; ?>
                <th>Date</th>
                <th>Description</th>
                <th>Category</th>
                <th>Sub Category</th>
                <th>Payment</th>
                <th>Payee</th>
                <th>Amount</th>
                <th>Recorded By</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($expenses as $ex): ?>
                <tr>
                    <td><?php echo $ex['id']; ?></td>
                    <?php if ($user['role_name'] === 'admin'): ?><td><?php echo htmlspecialchars($ex['branch_name']); ?></td><?php endif; ?>
                    <td><?php echo htmlspecialchars($ex['expense_date']); ?></td>
                    <td><?php echo htmlspecialchars($ex['description']); ?></td>
                    <td><?php echo htmlspecialchars($ex['category']); ?></td>
                    <td><?php echo htmlspecialchars($ex['subcategory']); ?></td>
                    <td><?php echo htmlspecialchars($ex['payment_method']); ?></td>
                     <td><?php echo htmlspecialchars($ex['payee_name']); ?></td>
                    <td><?php echo number_format($ex['amount'], 2); ?></td>
                    <td><?php echo htmlspecialchars($ex['created_by_name']); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- jQuery and DataTables JS -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    $('#expensesTable').DataTable();
});
</script>
</body>
</html>