<?php
/**
 * admin_activity_reverse.php
 * Admin-only console to view recent activity and reverse supported actions.
 *
 * Supported now:
 *   - CashDraw  → puts money back (cash/bank/wallet) + reverse journal + fixes cash_drawer_daily
 *   - WriteOff  → returns stock to batch + inserts negative write_off + logs reversal
 *
 * All other actions (Sales, Purchases, Transfers, Payments, etc.) are SHOWN but
 * not reversible yet. They’re labelled "Planned" and the Reverse button is disabled.
 */

require_once 'includes/header.php';
checkRole(['admin']); // ADMIN ONLY

/* ---------- helpers ---------- */
function alert($type,$msg){
  return '<div class="alert alert-'.$type.' alert-dismissible fade show" role="alert">'
       . htmlspecialchars($msg)
       . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
}
function table_exists(PDO $pdo,string $t):bool{
  try{ $q=$pdo->query("SHOW TABLES LIKE ".$pdo->quote($t)); return (bool)$q->fetchColumn(); }catch(Throwable $e){ return false; }
}
function first_row(PDO $pdo,$sql,$params){
  $st=$pdo->prepare($sql); $st->execute($params); return $st->fetch(PDO::FETCH_ASSOC);
}

/* ---------- tiny audit table (idempotent) ---------- */
try{
  $pdo->exec("CREATE TABLE IF NOT EXISTS reversal_audit (
    id INT AUTO_INCREMENT PRIMARY KEY,
    log_id INT NOT NULL,
    reversed_by INT NOT NULL,
    reversed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes VARCHAR(255) NULL,
    INDEX (log_id),
    INDEX (reversed_by)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}catch(Throwable $e){ /* ignore */ }

/* ---------- filters ---------- */
$start = $_GET['start'] ?? date('Y-m-d');
$end   = $_GET['end']   ?? date('Y-m-d');
$branch_id = isset($_GET['branch_id']) ? (int)$_GET['branch_id'] : 0;
$action    = trim($_GET['action'] ?? '');

$where = " al.created_at BETWEEN :s AND :t ";
$params = [':s'=>$start.' 00:00:00', ':t'=>$end.' 23:59:59'];
if ($branch_id) { $where .= " AND al.branch_id = :b "; $params[':b']=$branch_id; }
if ($action!=='') { $where .= " AND al.action = :a "; $params[':a']=$action; }

/* ---------- branches for filter ---------- */
$branches=[];
try{ $branches=$pdo->query("SELECT id,name FROM branches ORDER BY name")->fetchAll(PDO::FETCH_ASSOC); }catch(Throwable $e){}

/* ---------- supported vs planned sets ---------- */
// Originally only a handful of activity types were reversible (CashDraw and WriteOff)
// but administrators requested that *all* logged activities be reversible.  To
// accomplish this we merge the previously “planned” list into the supported list.
// When a reversal is requested for an action that doesn’t have bespoke undo
// logic implemented (i.e. anything other than CashDraw or WriteOff) the system
// will record the reversal in the audit log and add a corresponding activity
// entry, but it will **not** attempt to roll back the underlying data.  This
// ensures there is an audit trail for the reversal request without risking
// silent data corruption.  See the reversal section below for details.
$supported = [
  // original supported actions
  'CashDraw',
  'WriteOff',
  // sales-related actions
  'Sale','SaleReturn','SaleVoid','CustomerPayment',
  // purchase-related actions
  'Purchase','PurchaseReturn','SupplierPayment',
  // stock/transfers
  'StockTransfer','Transfer','TransferPayment','StockAdjust',
  // cargo
  'CargoService','CargoPayment',
  // banking & journals
  'BankDeposit','BankWithdrawal','BankTransfer',
  'Expense','Journal','Income',
  // miscellaneous actions that appear in logs
  'OpeningStock','Stock','Pos','Sales','Purchases','Transfers'
];
// Keeping a separate planned list for legacy reference only; currently unused.
$planned   = [];

/* ---------- POST: reverse ---------- */
$msg='';
if (($_POST['do'] ?? '')==='reverse' && isset($_POST['log_id']) && ctype_digit($_POST['log_id'])) {
  $log_id=(int)$_POST['log_id'];
  $log=first_row($pdo,"SELECT * FROM activity_logs WHERE id=:id",[':id'=>$log_id]);
  if (!$log){ $msg=alert('danger','Activity not found.'); }
  else {
    // already reversed?
    $already = first_row($pdo,"SELECT id FROM reversal_audit WHERE log_id=:l",[':l'=>$log_id]);
    if ($already){ $msg=alert('warning','This activity was already reversed.'); }
    else {
      if (!in_array($log['action'],$supported,true)) {
        $msg=alert('secondary','This action type is not reversible yet.');
      } else {
        $pdo->beginTransaction();
        try{
          if ($log['action']==='CashDraw') {
            // find the cash_draw row (timestamp±5s, user, branch)
            $draw = first_row(
              $pdo,
              "SELECT * FROM cash_draws
               WHERE branch_id=:b AND created_by=:u
                 AND ABS(TIMESTAMPDIFF(SECOND, created_at, :ts))<=5
               ORDER BY id DESC LIMIT 1",
              [':b'=>(int)$log['branch_id'], ':u'=>(int)$log['user_id'], ':ts'=>$log['created_at']]
            );
            if (!$draw) throw new Exception('Matching CashDraw record not found.');

            $amount = (float)$draw['amount'];
            $acct   = strtolower($draw['source_type']); // 'cash'|'bank'|'wallet'
            $desc   = sprintf('REVERSAL of CashDraw #%d (log #%d)',$draw['id'],$log['id']);

            // opposite journal entry
            $pdo->prepare("INSERT INTO journal_entries (branch_id, entry_date, account_type, amount, description, created_by)
                           VALUES (?,?,?,?,?,?)")
                ->execute([
                  (int)$draw['branch_id'],
                  $draw['draw_date'],
                  $acct,
                  $amount, // put back the amount
                  $desc,
                  (int)$user['id']
                ]);

            // adjust day sheet if CASH
            if ($acct==='cash' && table_exists($pdo,'cash_drawer_daily')) {
              $pdo->prepare("UPDATE cash_drawer_daily
                             SET other_cash_out = GREATEST(other_cash_out - :a,0),
                                 calculated_closing_balance = calculated_closing_balance + :a
                             WHERE branch_id=:b AND business_date=:d
                             LIMIT 1")
                  ->execute([':a'=>$amount, ':b'=>(int)$draw['branch_id'], ':d'=>$draw['draw_date']]);
            }

            // audit + log
            $pdo->prepare("INSERT INTO reversal_audit (log_id, reversed_by, notes) VALUES (?,?,?)")
                ->execute([$log_id,(int)$user['id'],'CashDraw reversed']);
            $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, branch_id)
                           VALUES (?,?,?,?)")
                ->execute([(int)$user['id'],'Reverse',$desc,(int)$log['branch_id']]);

          } elseif ($log['action']==='WriteOff') {
            $wo = first_row(
              $pdo,
              "SELECT w.*
                 FROM write_offs w
                WHERE w.branch_id=:b
                  AND w.created_by=:u
                  AND ABS(TIMESTAMPDIFF(SECOND, w.write_off_date, :ts))<=5
                ORDER BY w.id DESC LIMIT 1",
              [':b'=>(int)$log['branch_id'], ':u'=>(int)$log['user_id'], ':ts'=>$log['created_at']]
            );
            if (!$wo) throw new Exception('Matching WriteOff record not found.');

            $qty=(int)$wo['quantity']; $cp=(float)$wo['cost_price'];
            if ($qty<=0) throw new Exception('Suspicious original write-off quantity.');

            // return to stock
            $pdo->prepare("UPDATE stock_batches SET quantity = quantity + :q WHERE id=:bid")
                ->execute([':q'=>$qty, ':bid'=>(int)$wo['batch_id']]);

            // compensating negative write-off (keeps audit trail)
            $pdo->prepare("INSERT INTO write_offs (batch_id, product_id, branch_id, quantity, cost_price, write_off_date, remarks, created_by)
                           VALUES (?,?,?,?,?,?,?,?)")
                ->execute([
                  (int)$wo['batch_id'],
                  (int)$wo['product_id'],
                  (int)$wo['branch_id'],
                  -$qty,
                  $cp,
                  date('Y-m-d H:i:s'),
                  'REVERSAL of write-off #'.$wo['id'].' (log #'.$log['id'].')',
                  (int)$user['id']
                ]);

            $pdo->prepare("INSERT INTO reversal_audit (log_id, reversed_by, notes) VALUES (?,?,?)")
                ->execute([$log_id,(int)$user['id'],'WriteOff reversed']);
            $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, branch_id)
                           VALUES (?,?,?,?)")
                ->execute([(int)$user['id'],'Reverse','Reversed write-off #'.$wo['id'],(int)$log['branch_id']]);

          } else {
            if ($log['action']==='Sale') {
              // Attempt to parse sale ID from description, e.g. "Created sale #123"
              if (preg_match('/#(\d+)/', $log['description'], $m)) {
                $saleId = (int)$m[1];
              } else {
                throw new Exception('Could not parse sale ID from description.');
              }
              // fetch sale header
              $sale = first_row($pdo, "SELECT * FROM sales WHERE id=:id", [':id'=>$saleId]);
              if (!$sale) throw new Exception('Sale record not found.');
              // restore stock for each sale item
              $stItems = $pdo->prepare("SELECT batch_id, quantity FROM sale_items WHERE sale_id=?");
              $stItems->execute([$saleId]);
              $items = $stItems->fetchAll(PDO::FETCH_ASSOC);
              foreach ($items as $it) {
                $bid = (int)$it['batch_id'];
                $qty = (int)$it['quantity'];
                if ($bid>0 && $qty>0) {
                  $pdo->prepare("UPDATE stock_batches SET quantity = quantity + :q WHERE id=:bid")
                      ->execute([':q'=>$qty, ':bid'=>$bid]);
                }
              }
              // delete sale items
              $pdo->prepare("DELETE FROM sale_items WHERE sale_id=?")->execute([$saleId]);
              // delete sale payments (if table exists)
              if (table_exists($pdo,'sale_payments')) {
                $pdo->prepare("DELETE FROM sale_payments WHERE sale_id=?")->execute([$saleId]);
              }
              // delete card_commissions
              if (table_exists($pdo,'card_commissions')) {
                $pdo->prepare("DELETE FROM card_commissions WHERE sale_id=?")->execute([$saleId]);
              }
              // delete related expenses (card commission) by description
              if (table_exists($pdo,'expenses')) {
                $pdo->prepare("DELETE FROM expenses WHERE description LIKE ? AND category='Bank Charges' AND subcategory='Card Commission'")->execute(["Card commission for Sale #{$saleId}"]);
              }
              // reverse journal entries for card commission fee
              if (table_exists($pdo,'journal_entries')) {
                // remove existing commission entries (bank and other) for this sale
                $pdo->prepare("DELETE FROM journal_entries WHERE description = ? AND (account_type='bank' OR account_type='other')")
                    ->execute(["Card commission fee for Sale #{$saleId}"]);
              }
              // delete sale header
              $pdo->prepare("DELETE FROM sales WHERE id=?")->execute([$saleId]);
              // audit + log
              $note = 'Sale reversed';
              $desc = 'Reversed sale #'.$saleId;
              $pdo->prepare("INSERT INTO reversal_audit (log_id, reversed_by, notes) VALUES (?,?,?)")
                  ->execute([$log_id,(int)$user['id'],$note]);
              $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, branch_id)
                             VALUES (?,?,?,?)")
                  ->execute([(int)$user['id'],'Reverse',$desc,(int)$log['branch_id']]);
            } elseif ($log['action']==='Purchase') {
              // parse purchase ID from description "Created purchase #123"
              if (preg_match('/#(\d+)/', $log['description'], $m)) {
                $purId = (int)$m[1];
              } else {
                throw new Exception('Could not parse purchase ID from description.');
              }
              $purchase = first_row($pdo, "SELECT * FROM purchases WHERE id=:id", [':id'=>$purId]);
              if (!$purchase) throw new Exception('Purchase record not found.');
              // fetch purchase items
              $stItems = $pdo->prepare("SELECT product_id, batch_no, quantity FROM purchase_items WHERE purchase_id=?");
              $stItems->execute([$purId]);
              $pItems = $stItems->fetchAll(PDO::FETCH_ASSOC);
              // reverse stock: subtract quantities from stock_batches
              foreach ($pItems as $it) {
                $pid = (int)$it['product_id'];
                $qty = (int)$it['quantity'];
                $batchNo = trim($it['batch_no']);
                if ($pid>0 && $qty>0) {
                  // find batch id by product_id, branch and batch_no
                  $stb = $pdo->prepare("SELECT id FROM stock_batches WHERE product_id=:p AND branch_id=:b AND batch_no=:bn LIMIT 1");
                  $stb->execute([':p'=>$pid, ':b'=>$purchase['branch_id'], ':bn'=>$batchNo]);
                  $rowB = $stb->fetch(PDO::FETCH_ASSOC);
                  if ($rowB) {
                    $pdo->prepare("UPDATE stock_batches SET quantity = GREATEST(quantity - :q, 0) WHERE id=:id")
                        ->execute([':q'=>$qty, ':id'=>$rowB['id']]);
                  }
                }
              }
              // delete purchase items
              $pdo->prepare("DELETE FROM purchase_items WHERE purchase_id=?")->execute([$purId]);
              // delete purchase payments
              if (table_exists($pdo,'purchase_payments')) {
                $pdo->prepare("DELETE FROM purchase_payments WHERE purchase_id=?")->execute([$purId]);
              }
              // delete purchase header
              $pdo->prepare("DELETE FROM purchases WHERE id=?")->execute([$purId]);
              // audit + log
              $note = 'Purchase reversed';
              $desc = 'Reversed purchase #'.$purId;
              $pdo->prepare("INSERT INTO reversal_audit (log_id, reversed_by, notes) VALUES (?,?,?)")
                  ->execute([$log_id,(int)$user['id'],$note]);
              $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, branch_id)
                             VALUES (?,?,?,?)")
                  ->execute([(int)$user['id'],'Reverse',$desc,(int)$log['branch_id']]);
            } else {
              // Generic reversal: record audit and create a reversal log entry.
              // We do not attempt to undo the underlying data for actions other than
              // CashDraw, WriteOff, Sale or Purchase.  Administrators must manually correct any
              // financial or inventory impacts outside of this tool.
              $note = 'Generic reversal for action '. $log['action'];
              $desc = 'REVERSAL of '. $log['action'] .' (log #'. $log['id'] .'): '. $log['description'];
              $pdo->prepare("INSERT INTO reversal_audit (log_id, reversed_by, notes) VALUES (?,?,?)")
                  ->execute([$log_id,(int)$user['id'],$note]);
              $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, branch_id)
                             VALUES (?,?,?,?)")
                  ->execute([(int)$user['id'],'Reverse',$desc,(int)$log['branch_id']]);
            }
          }

          $pdo->commit();
          // Provide a nuanced message: if generic, inform that data was not rolled back
          if (in_array($log['action'], ['CashDraw','WriteOff','Sale','Purchase'], true)) {
            $msg=alert('success','Reversal completed.');
          } else {
            $msg=alert('warning','Reversal recorded. Please note: underlying data was not automatically undone.');
          }
        }catch(Throwable $e){
          $pdo->rollBack();
          $msg=alert('danger','Reverse failed: '.$e->getMessage());
        }
      }
    }
  }
}

/* ---------- load activities ---------- */
$sql="SELECT al.*, u.username, b.name AS branch_name,
             EXISTS(SELECT 1 FROM reversal_audit ra WHERE ra.log_id=al.id) AS is_reversed
      FROM activity_logs al
      LEFT JOIN users u ON u.id=al.user_id
      LEFT JOIN branches b ON b.id=al.branch_id
      WHERE $where
      ORDER BY al.created_at DESC, al.id DESC
      LIMIT 500";
$st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll(PDO::FETCH_ASSOC);

/* actions list for filter dropdown */
$actions=[];
try{ $actions=$pdo->query("SELECT DISTINCT action FROM activity_logs ORDER BY action")->fetchAll(PDO::FETCH_COLUMN); }catch(Throwable $e){}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Reverse Activities (Admin)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
  <style>
    .badge-soft{background:#eef2ff;color:#1e3a8a;border-radius:12px;padding:.25rem .5rem}
    .badge-plan{background:#e5e7eb;color:#374151;border-radius:12px;padding:.25rem .5rem}
    .badge-yes{background:#fff7ed;color:#9a3412;border-radius:12px;padding:.25rem .5rem}
    .table td{vertical-align: middle;}
  </style>
</head>
<body>
<?php include 'includes/nav.php'; ?>
<div class="container my-4">
  <div class="d-flex align-items-center justify-content-between mb-2">
    <h3 class="mb-0">Reverse Activities</h3>
    <div class="small">
      <span class="badge-yes me-1">Supported</span>
      <span class="badge-plan me-1">Planned</span>
      <span class="badge bg-success">Reversed</span>
    </div>
  </div>

  <?php echo $msg; ?>

  <form class="row g-2 align-items-end mb-3" method="get">
    <div class="col-md-2">
      <label class="form-label">From</label>
      <input type="date" class="form-control" name="start" value="<?php echo htmlspecialchars($start); ?>">
    </div>
    <div class="col-md-2">
      <label class="form-label">To</label>
      <input type="date" class="form-control" name="end" value="<?php echo htmlspecialchars($end); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">Branch</label>
      <select class="form-select" name="branch_id">
        <option value="0">All</option>
        <?php foreach($branches as $b): ?>
          <option value="<?php echo (int)$b['id']; ?>" <?php echo ($branch_id===(int)$b['id']?'selected':''); ?>>
            <?php echo htmlspecialchars($b['name']); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Action</label>
      <select class="form-select" name="action">
        <option value="">Any</option>
        <?php foreach ($actions as $a): ?>
          <option value="<?php echo htmlspecialchars($a); ?>" <?php echo ($action===$a?'selected':''); ?>>
            <?php echo htmlspecialchars($a); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2">
      <button class="btn btn-primary w-100">Apply</button>
    </div>
  </form>

  <div class="table-responsive">
    <table id="actTable" class="table table-striped table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Date/Time</th>
          <th>Branch</th>
          <th>User</th>
          <th>Action</th>
          <th>Description</th>
          <th>Reverse</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($rows as $r): ?>
        <?php
          $isSupported = in_array($r['action'],$supported,true);
          $isPlanned   = in_array($r['action'],$planned,true);
          $statusBadge = $r['is_reversed'] ? '<span class="badge bg-success">Reversed</span>'
                         : ($isSupported ? '<span class="badge-yes">Supported</span>'
                         : ($isPlanned ? '<span class="badge-plan">Planned</span>'
                                       : '<span class="badge bg-secondary">Unknown</span>'));
          $disabled = ($r['is_reversed'] || !$isSupported) ? 'disabled' : '';
          $title    = $r['is_reversed'] ? 'Already reversed'
                     : ($isSupported ? 'Reverse this activity'
                     : ($isPlanned ? 'Reversal planned (disabled)'
                                   : 'Not supported (disabled)'));
        ?>
        <tr>
          <td><?php echo (int)$r['id']; ?></td>
          <td><?php echo htmlspecialchars($r['created_at']); ?></td>
          <td><?php echo htmlspecialchars($r['branch_name'] ?? ''); ?></td>
          <td><?php echo htmlspecialchars($r['username'] ?? ('User #'.$r['user_id'])); ?></td>
          <td><?php echo htmlspecialchars($r['action']); ?> <span class="ms-1"><?php echo $statusBadge; ?></span></td>
          <td><?php echo htmlspecialchars($r['description']); ?></td>
          <td style="width:140px">
            <form method="post" class="d-inline" onsubmit="return confirm('Reverse this activity?');">
              <input type="hidden" name="do" value="reverse">
              <input type="hidden" name="log_id" value="<?php echo (int)$r['id']; ?>">
              <button class="btn btn-sm btn-danger" <?php echo $disabled; ?> title="<?php echo htmlspecialchars($title); ?>">Reverse</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <p class="text-muted small mt-2">
    The reverse tool allows administrators to record a reversal for any action listed above.  
    Detailed undo logic is implemented for <strong>CashDraw</strong>, <strong>WriteOff</strong>, <strong>Sale</strong> and <strong>Purchase</strong> actions.  For
    other actions the system will simply mark the activity as reversed, add an audit entry and a
    corresponding log entry, but it will not automatically adjust your inventory, accounting or
    financial records.  Please ensure any required manual corrections are performed in your
    operational databases.
  </p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function(){
  $('#actTable').DataTable({ pageLength: 25, order:[[1,'desc']] });
});
</script>
</body>
</html>
